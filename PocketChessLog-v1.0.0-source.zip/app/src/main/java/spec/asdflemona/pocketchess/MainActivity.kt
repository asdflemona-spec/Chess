package spec.asdflemona.pocketchess

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity: Activity() {
    private var game=ChessGame(); private lateinit var board:ChessView; private lateinit var moves:TextView; private lateinit var status:TextView
    private var human='w'; private var thinking=false; private var level=2
    override fun onCreate(b:Bundle?){super.onCreate(b); buildUi()}
    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,10,14,10);setBackgroundColor(Color.rgb(38,36,33))}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text="POCKET CHESS";textSize=20f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD;setPadding(8,8,8,8)}
        status=TextView(this).apply{textSize=14f;setTextColor(Color.rgb(190,190,190));gravity=Gravity.END;setPadding(8,8,8,8)}
        top.addView(title,LinearLayout.LayoutParams(0,-2,1f));top.addView(status,LinearLayout.LayoutParams(0,-2,1f));root.addView(top)
        board=ChessView(this,game){ humanMoved() }; root.addView(board,LinearLayout.LayoutParams(-1,0,1f))
        moves=TextView(this).apply{textSize=15f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(49,47,43));setPadding(18,14,18,14);setTextIsSelectable(true);minHeight=100}
        root.addView(moves)
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER}
        fun btn(t:String, f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
        bar.addView(btn("↶ Undo"){undoPair()});bar.addView(btn("New"){newGame()});bar.addView(btn("PGN"){copyPgn()});bar.addView(btn("Level $level"){ level=if(level==4)1 else level+1;(it as Button).text="Level $level" })
        root.addView(bar);setContentView(root);refresh()
    }
    private fun newGame(){if(thinking)return;game=ChessGame();board.game=game;board.sel=-1;refresh();board.invalidate()}
    private fun undoPair(){if(thinking)return; if(game.undo()) game.undo(); board.sel=-1;refresh();board.invalidate()}
    private fun copyPgn(){(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("PGN",game.pgn()));Toast.makeText(this,"PGN copied",Toast.LENGTH_SHORT).show()}
    private fun refresh(){moves.text=game.moveText().ifBlank{"Your game record appears here."};status.text=when{thinking->"Computer thinking…";game.result()!=null->game.resultText();game.turn==human->"Your turn";else->"Computer"}}
    private fun humanMoved(){refresh();val end=game.result();if(end!=null){showEnd();return};computerMove()}
    private fun computerMove(){thinking=true;board.isEnabled=false;refresh();val snapshot=game.copyGame();thread{val m=snapshot.bestMove(level);runOnUiThread{if(m!=null&&game.result()==null)game.play(m);thinking=false;board.isEnabled=true;board.sel=-1;board.invalidate();refresh();if(game.result()!=null)showEnd()}}}
    private fun showEnd(){Toast.makeText(this,game.resultText(),Toast.LENGTH_LONG).show()}
}

data class Move(val from:Int,val to:Int,val promotion:Char='Q',val castle:Boolean=false,val ep:Boolean=false)
data class State(val board:CharArray,val turn:Char,val castle:String,val ep:Int,val half:Int,val full:Int,val move:Move?,val san:String)

class ChessGame {
    var board=CharArray(64){'.'};var turn='w';private var castle="KQkq";private var ep=-1;private var half=0;private var full=1
    private val history=mutableListOf<State>();private val sans=mutableListOf<String>();var lastMove:Move?=null
    init{reset()}
    private fun reset(){val back="RNBQKBNR";for(i in 0..7){board[i]=back[i];board[8+i]='P';board[48+i]='p';board[56+i]=back[i].lowercaseChar()}}
    fun copyGame():ChessGame{val g=ChessGame();g.board=board.clone();g.turn=turn;g.castle=castle;g.ep=ep;g.half=half;g.full=full;g.history.clear();g.sans.clear();g.sans.addAll(sans);g.lastMove=lastMove;return g}
    private fun white(p:Char)=p in "PNBRQK";private fun mine(p:Char,s:Char)=if(s=='w')white(p) else p in "pnbrqk";private fun enemy(s:Char)=if(s=='w')'b' else 'w'
    private fun sq(i:Int)="${('a'.code+i%8).toChar()}${i/8+1}"
    fun legal(s:Char=turn):List<Move>{val out=ArrayList<Move>();for(i in 0..63)if(mine(board[i],s))for(m in pseudo(i,s)){val snap=snapshot(m,"");applyRaw(m);val ok=!inCheck(s);restore(snap);if(ok)out+=m};return out}
    private fun pseudo(i:Int,s:Char):List<Move>{val p=board[i];val r=i/8;val c=i%8;val out=ArrayList<Move>();fun add(rr:Int,cc:Int){if(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(board[t]=='.'||!mine(board[t],s))out+=Move(i,t)}}
        when(p.lowercaseChar()){
            'p'->{val d=if(s=='w')1 else -1;val pr=if(s=='w')7 else 0;fun pawnMove(t:Int,cap:Boolean=false,epc:Boolean=false){if(t/8==pr)for(q in "QRBN")out+=Move(i,t,q,false,epc) else out+=Move(i,t,'Q',false,epc)};val one=r+d;if(one in 0..7&&board[one*8+c]=='.'){pawnMove(one*8+c);val st=if(s=='w')1 else 6;val two=r+2*d;if(r==st&&board[two*8+c]=='.')out+=Move(i,two*8+c)};for(dc in intArrayOf(-1,1)){val cc=c+dc;if(one in 0..7&&cc in 0..7){val t=one*8+cc;if(board[t]!='.'&&!mine(board[t],s))pawnMove(t,true) else if(t==ep)pawnMove(t,true,true)}}}
            'n'->for((dr,dc) in arrayOf(2 to 1,2 to -1,-2 to 1,-2 to -1,1 to 2,1 to -2,-1 to 2,-1 to -2))add(r+dr,c+dc)
            'b','r','q'->{val ds=ArrayList<Pair<Int,Int>>();if(p.lowercaseChar()!='r')ds+=listOf(1 to 1,1 to -1,-1 to 1,-1 to -1);if(p.lowercaseChar()!='b')ds+=listOf(1 to 0,-1 to 0,0 to 1,0 to -1);for((dr,dc)in ds){var rr=r+dr;var cc=c+dc;while(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(board[t]=='.')out+=Move(i,t)else{if(!mine(board[t],s))out+=Move(i,t);break};rr+=dr;cc+=dc}}}
            'k'->{for(dr in -1..1)for(dc in -1..1)if(dr!=0||dc!=0)add(r+dr,c+dc);if(!inCheck(s)){if(s=='w'&&i==4){if('K'in castle&&board[5]=='.'&&board[6]=='.'&&!attacked(5,'b')&&!attacked(6,'b'))out+=Move(4,6,castle=true);if('Q'in castle&&board[3]=='.'&&board[2]=='.'&&board[1]=='.'&&!attacked(3,'b')&&!attacked(2,'b'))out+=Move(4,2,castle=true)};if(s=='b'&&i==60){if('k'in castle&&board[61]=='.'&&board[62]=='.'&&!attacked(61,'w')&&!attacked(62,'w'))out+=Move(60,62,castle=true);if('q'in castle&&board[59]=='.'&&board[58]=='.'&&board[57]=='.'&&!attacked(59,'w')&&!attacked(58,'w'))out+=Move(60,58,castle=true)}}}
        };return out}
    private fun attacked(t:Int,by:Char):Boolean{for(i in 0..63)if(mine(board[i],by)){val p=board[i].lowercaseChar();val r=i/8;val c=i%8;val tr=t/8;val tc=t%8;when(p){'p'->if(tr-r==(if(by=='w')1 else -1)&&abs(tc-c)==1)return true;'n'->if((abs(tr-r)==2&&abs(tc-c)==1)||(abs(tr-r)==1&&abs(tc-c)==2))return true;'k'->if(max(abs(tr-r),abs(tc-c))==1)return true;'b','r','q'->{val dr=tr-r;val dc=tc-c;val diag=abs(dr)==abs(dc);val straight=dr==0||dc==0;if((p=='b'&&diag)||(p=='r'&&straight)||(p=='q'&&(diag||straight))){val sr=dr.sign;val sc=dc.sign;var rr=r+sr;var cc=c+sc;var clear=true;while(rr!=tr||cc!=tc){if(board[rr*8+cc]!='.'){clear=false;break};rr+=sr;cc+=sc};if(clear)return true}}}};return false}
    fun inCheck(s:Char):Boolean{val k=board.indexOf(if(s=='w')'K' else 'k');return k<0||attacked(k,enemy(s))}
    private fun snapshot(m:Move?,san:String)=State(board.clone(),turn,castle,ep,half,full,m,san)
    private fun restore(s:State){board=s.board.clone();turn=s.turn;castle=s.castle;ep=s.ep;half=s.half;full=s.full;lastMove=history.lastOrNull()?.move}
    private fun applyRaw(m:Move){val p=board[m.from];if(m.ep){val cap=m.to+(if(white(p))-8 else 8);board[cap]='.'};board[m.to]=p;board[m.from]='.';if(m.castle){if(m.to==6){board[5]=board[7];board[7]='.'};if(m.to==2){board[3]=board[0];board[0]='.'};if(m.to==62){board[61]=board[63];board[63]='.'};if(m.to==58){board[59]=board[56];board[56]='.'}};if(p.lowercaseChar()=='p'&&(m.to/8==0||m.to/8==7))board[m.to]=if(white(p))m.promotion else m.promotion.lowercaseChar()}
    fun play(m:Move):Boolean{val lm=legal().firstOrNull{it.from==m.from&&it.to==m.to&&it.promotion==m.promotion}?:return false;val p=board[lm.from];val captured=if(lm.ep)true else board[lm.to]!='.';val old=snapshot(lm,"");history+=old;val sanBase=sanBase(lm,p,captured);applyRaw(lm);updateRights(lm,p);ep=if(p.lowercaseChar()=='p'&&abs(lm.to-lm.from)==16)(lm.to+lm.from)/2 else -1;half=if(p.lowercaseChar()=='p'||captured)0 else half+1;if(turn=='b')full++;turn=enemy(turn);lastMove=lm;val suffix=if(inCheck(turn))if(legal().isEmpty())"#" else "+" else "";sans+=sanBase+suffix;return true}
    private fun updateRights(m:Move,p:Char){if(p=='K')castle=castle.replace("K","").replace("Q","");if(p=='k')castle=castle.replace("k","").replace("q","");if(m.from==0||m.to==0)castle=castle.replace("Q","");if(m.from==7||m.to==7)castle=castle.replace("K","");if(m.from==56||m.to==56)castle=castle.replace("q","");if(m.from==63||m.to==63)castle=castle.replace("k","")}
    private fun sanBase(m:Move,p:Char,cap:Boolean):String{if(m.castle)return if(m.to%8==6)"O-O" else "O-O-O";val pc=p.uppercaseChar();val piece=if(pc=='P')"" else pc.toString();var dis="";if(pc!='P'){val peers=legal().filter{it.to==m.to&&it.from!=m.from&&board[it.from].uppercaseChar()==pc};if(peers.isNotEmpty()){val sameFile=peers.any{it.from%8==m.from%8};val sameRank=peers.any{it.from/8==m.from/8};dis=when{!sameFile->('a'.code+m.from%8).toChar().toString();!sameRank->(m.from/8+1).toString();else->sq(m.from)}}}else if(cap)dis=('a'.code+m.from%8).toChar().toString();val promo=if(pc=='P'&&(m.to/8==0||m.to/8==7))"=${m.promotion}" else "";return piece+dis+(if(cap)"x" else "")+sq(m.to)+promo}
    fun undo():Boolean{if(history.isEmpty())return false;val s=history.removeAt(history.lastIndex);if(sans.isNotEmpty())sans.removeAt(sans.lastIndex);restore(s);lastMove=history.lastOrNull()?.move;return true}
    fun result():String?{val l=legal();if(l.isEmpty())return if(inCheck(turn))if(turn=='w')"0-1" else "1-0" else "1/2-1/2";if(half>=100)return "1/2-1/2";return null}
    fun resultText()=when(result()){"1-0"->"White wins by checkmate";"0-1"->"Black wins by checkmate";"1/2-1/2"->"Draw";else->"Game in progress"}
    fun moveText()=sans.chunked(2).mapIndexed{i,x->"${i+1}. ${x.joinToString("  ")}"}.joinToString("    ")
    fun pgn():String="[Event \"Pocket Chess\"]\n[Site \"Android\"]\n[Result \"${result()?:"*"}\"]\n\n${moveText()} ${result()?:"*"}"
    private fun eval():Int{val v=mapOf('p' to 100,'n' to 320,'b' to 330,'r' to 500,'q' to 900,'k' to 0);var x=0;for(i in 0..63){val p=board[i];if(p!='.'){var n=v[p.lowercaseChar()]?:0;val r=i/8;val c=i%8;val center=(3.5-abs(3.5-c))+(3.5-abs(3.5-r));if(p.lowercaseChar() in "nb")n+=(center*5).toInt();x+=if(white(p))n else -n}};return x}
    fun bestMove(level:Int):Move?{val budget=listOf(0L,180L,450L,900L,1600L)[level.coerceIn(1,4)];val deadline=System.currentTimeMillis()+budget;var best:Move?=null;var depth=1;while(depth<=6&&System.currentTimeMillis()<deadline){val root=legal();var bestScore=Int.MAX_VALUE;var completed=true;for(m in root.sortedByDescending{captureScore(it)}){if(System.currentTimeMillis()>=deadline){completed=false;break};val s=snapshot(null,"");applyRaw(m);turn='w';val sc=search(depth-1,-30000,30000,true,deadline);restore(s);if(sc<bestScore){bestScore=sc;if(completed)best=m}};if(!completed)break;depth++};return best?:legal().firstOrNull()}
    private fun captureScore(m:Move)=if(board[m.to]!='.')10 else 0
    private fun search(d:Int,a0:Int,b0:Int,maxi:Boolean,dl:Long):Int{if(System.currentTimeMillis()>=dl||d<=0)return eval();val ms=legal(if(maxi)'w' else 'b');if(ms.isEmpty())return if(inCheck(if(maxi)'w' else 'b'))if(maxi)-29000 else 29000 else 0;var a=a0;var b=b0;if(maxi){var x=-30000;for(m in ms.sortedByDescending{captureScore(it)}){val s=snapshot(null,"");applyRaw(m);turn='b';x=max(x,search(d-1,a,b,false,dl));restore(s);a=max(a,x);if(a>=b)break};return x}else{var x=30000;for(m in ms.sortedByDescending{captureScore(it)}){val s=snapshot(null,"");applyRaw(m);turn='w';x=min(x,search(d-1,a,b,true,dl));restore(s);b=min(b,x);if(a>=b)break};return x}}
}

class ChessView(c:Context,var game:ChessGame,val moved:()->Unit):View(c){var sel=-1;private val light=Paint().apply{color=Color.rgb(240,217,181)};private val dark=Paint().apply{color=Color.rgb(181,136,99)};private val selected=Paint().apply{color=Color.argb(180,246,246,105)};private val last=Paint().apply{color=Color.argb(120,205,210,70)};private val check=Paint().apply{color=Color.argb(185,220,55,55)};private val dot=Paint(1).apply{color=Color.argb(130,30,30,30)};private val ring=Paint(1).apply{color=Color.argb(130,30,30,30);style=Paint.Style.STROKE};private val txt=Paint(1).apply{textAlign=Paint.Align.CENTER;color=Color.BLACK};private val coord=Paint(1).apply{textSize=18f;typeface=Typeface.DEFAULT_BOLD}
    override fun onMeasure(w:Int,h:Int){val ww=MeasureSpec.getSize(w);setMeasuredDimension(ww,ww)}
    override fun onDraw(c:Canvas){val s=width/8f;for(r in 0..7)for(col in 0..7)c.drawRect(col*s,(7-r)*s,(col+1)*s,(8-r)*s,if((r+col)%2==0)dark else light);fun hi(i:Int,p:Paint){c.drawRect((i%8)*s,(7-i/8)*s,(i%8+1)*s,(8-i/8)*s,p)};game.lastMove?.let{hi(it.from,last);hi(it.to,last)};if(sel>=0)hi(sel,selected);val k=game.board.indexOf('K');if(k>=0&&game.inCheck('w'))hi(k,check);if(sel>=0){ring.strokeWidth=s*.07f;for(m in game.legal().filter{it.from==sel}){val cx=(m.to%8+.5f)*s;val cy=(7-m.to/8+.5f)*s;if(game.board[m.to]=='.')c.drawCircle(cx,cy,s*.13f,dot)else c.drawCircle(cx,cy,s*.40f,ring)}};txt.textSize=s*.68f;val mp=mapOf('K' to "♔",'Q' to "♕",'R' to "♖",'B' to "♗",'N' to "♘",'P' to "♙",'k' to "♚",'q' to "♛",'r' to "♜",'b' to "♝",'n' to "♞",'p' to "♟");for(i in 0..63)if(game.board[i]!='.')c.drawText(mp[game.board[i]]?:"",(i%8+.5f)*s,(7-i/8+.73f)*s,txt);for(col in 0..7){coord.color=if(col%2==0)light.color else dark.color;c.drawText(('a'.code+col).toChar().toString(),(col+1)*s-18,8*s-8,coord)};for(r in 0..7){coord.color=if(r%2==0)dark.color else light.color;c.drawText((r+1).toString(),5f,(7-r)*s+20,coord)}}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP||!isEnabled||game.turn!='w')return true;val s=width/8f;val col=(e.x/s).toInt();val r=7-(e.y/s).toInt();if(col !in 0..7||r !in 0..7)return true;val i=r*8+col;if(sel<0){if(game.board[i] in "PNBRQK")sel=i}else{val opts=game.legal().filter{it.from==sel&&it.to==i};if(opts.isNotEmpty()){val chosen=if(opts.size>1)opts.first{it.promotion=='Q'}else opts.first();game.play(chosen);sel=-1;invalidate();moved()}else sel=if(game.board[i] in "PNBRQK")i else -1};invalidate();return true}
}
