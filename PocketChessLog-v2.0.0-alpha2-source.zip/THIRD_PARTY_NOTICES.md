Chesslib by Ben-Hur Carlos Vieira Langoni Junior and contributors.
License: Apache License 2.0.
Source: https://github.com/bhlangonijr/chesslib
Used as an external dependency; source is not copied into this archive.
