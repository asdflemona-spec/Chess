package spec.asdflemona.pocketchess

import android.app.*
import android.os.Bundle
import android.view.*
import android.widget.*
import android.graphics.*
import com.github.bhlangonijr.chesslib.*
import com.github.bhlangonijr.chesslib.move.Move

class MainActivity : Activity() {
    private lateinit var controller: GameController
    private lateinit var boardView: ChessBoardView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        chooseSide()
    }

    private fun chooseSide() {
        AlertDialog.Builder(this).setTitle("Choose your side")
            .setItems(arrayOf("White", "Black")) { _, which -> startGame(if (which == 0) Side.WHITE else Side.BLACK) }
            .setCancelable(false).show()
    }

    private fun startGame(userSide: Side) {
        status = TextView(this).apply { textSize=18f; gravity=Gravity.CENTER; setPadding(8,20,8,20) }
        boardView = ChessBoardView(this)
        val reset = Button(this).apply { text="New game"; setOnClickListener { chooseSide() } }
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            addView(status, LinearLayout.LayoutParams(-1,-2))
            addView(boardView, LinearLayout.LayoutParams(-1,0,1f))
            addView(reset, LinearLayout.LayoutParams(-1,-2))
        }
        setContentView(root)
        controller = GameController(userSide, { render() }, { boardView.clearSelection() })
        boardView.bind(controller)
        render()
        controller.advanceIfOpponentTurn()
    }

    private fun render() {
        if (!::controller.isInitialized) return
        boardView.invalidate()
        status.text = controller.statusText()
    }
}

/** Domain/controller boundary: the UI never chooses or executes a random move. */
class GameController(
    val userSide: Side,
    private val changed: () -> Unit,
    private val clearSelection: () -> Unit
) {
    val board = Board()
    private val opponent = RandomOpponent()
    private var generation = 0L

    fun isUserTurn(): Boolean = board.sideToMove == userSide
    fun legalFrom(square: Square): List<Move> = if (isUserTurn()) board.legalMoves().filter { it.from == square } else emptyList()

    fun submitUserMove(from: Square, to: Square): Boolean {
        if (!isUserTurn() || isFinished()) return false
        val candidates = board.legalMoves().filter { it.from == from && it.to == to }
        if (candidates.isEmpty()) return false
        // Promotion defaults to queen in this minimal verification build.
        val chosen = candidates.firstOrNull { it.promotion.pieceType == PieceType.QUEEN } ?: candidates.first()
        board.doMove(chosen)
        clearSelection(); changed()
        advanceIfOpponentTurn()
        return true
    }

    fun advanceIfOpponentTurn() {
        if (isUserTurn() || isFinished()) return
        val token = ++generation
        val expectedFen = board.fen
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (token != generation || board.fen != expectedFen || isUserTurn() || isFinished()) return@postDelayed
            val chosen = opponent.choose(board.legalMoves()) ?: return@postDelayed
            board.doMove(chosen)
            changed()
        }, 550)
    }

    fun pieceAt(square: Square): Piece = board.getPiece(square)
    fun isFinished(): Boolean = board.isMated || board.isStaleMate || board.isDraw
    fun statusText(): String = when {
        board.isMated -> if (board.sideToMove == userSide) "Checkmate — you lost" else "Checkmate — you won"
        board.isStaleMate || board.isDraw -> "Draw"
        isUserTurn() -> "Your turn · ${userSide.name.lowercase()}"
        else -> "Opponent turn"
    }
}

/** The only component allowed to select randomly. It cannot touch Android UI or mutate Board. */
class RandomOpponent {
    fun choose(legalMoves: List<Move>): Move? = legalMoves.randomOrNull()
}

/** Input/view only: selects a source and submits an explicit from→to pair. */
class ChessBoardView(context: android.content.Context) : View(context) {
    private lateinit var controller: GameController
    private var selected: Square? = null
    private val light = Paint().apply { color=Color.rgb(238,238,210) }
    private val dark = Paint().apply { color=Color.rgb(118,150,86) }
    private val select = Paint().apply { color=Color.argb(150,246,246,105) }
    private val dot = Paint().apply { color=Color.argb(150,30,30,30) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign=Paint.Align.CENTER; typeface=Typeface.DEFAULT }

    fun bind(c: GameController) { controller=c }
    fun clearSelection() { selected=null; invalidate() }

    override fun onMeasure(w:Int,h:Int) { val size=minOf(MeasureSpec.getSize(w),MeasureSpec.getSize(h)); setMeasuredDimension(size,size) }

    override fun onDraw(c: Canvas) {
        if (!::controller.isInitialized) return
        val s=width/8f
        for (screenRow in 0..7) for (screenCol in 0..7) {
            val sq = squareFor(screenCol, screenRow)
            val left=screenCol*s; val top=screenRow*s
            c.drawRect(left,top,left+s,top+s,if((screenRow+screenCol)%2==0) light else dark)
            if(selected==sq) c.drawRect(left,top,left+s,top+s,select)
            val p=controller.pieceAt(sq)
            if(p != Piece.NONE) {
                text.textSize=s*.72f; text.color=if(p.pieceSide==Side.WHITE) Color.WHITE else Color.BLACK
                text.setShadowLayer(2f,1f,1f,if(p.pieceSide==Side.WHITE) Color.BLACK else Color.WHITE)
                c.drawText(symbol(p),left+s/2,top+s*.74f,text); text.clearShadowLayer()
            }
        }
        selected?.let { from -> controller.legalFrom(from).forEach { m ->
            val (col,row)=screenFor(m.to); c.drawCircle((col+.5f)*s,(row+.5f)*s,s*.10f,dot)
        }}
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if(e.action != MotionEvent.ACTION_UP || !::controller.isInitialized || !controller.isUserTurn() || controller.isFinished()) return true
        val s=width/8f; val col=(e.x/s).toInt(); val row=(e.y/s).toInt(); if(col !in 0..7 || row !in 0..7) return true
        val tapped=squareFor(col,row)
        val current=selected
        if(current == null) {
            val p=controller.pieceAt(tapped)
            if(p != Piece.NONE && p.pieceSide == controller.userSide && controller.legalFrom(tapped).isNotEmpty()) { selected=tapped; invalidate() }
            return true
        }
        if(tapped == current) { clearSelection(); return true }
        val p=controller.pieceAt(tapped)
        if(p != Piece.NONE && p.pieceSide == controller.userSide) { selected=if(controller.legalFrom(tapped).isEmpty()) null else tapped; invalidate(); return true }
        if(!controller.submitUserMove(current,tapped)) clearSelection()
        return true
    }

    private fun squareFor(col:Int,row:Int):Square {
        val whiteBottom=controller.userSide==Side.WHITE
        val file=if(whiteBottom) col else 7-col
        val rank=if(whiteBottom) 7-row else row
        return Square.valueOf("${('A'.code+file).toChar()}${rank+1}")
    }
    private fun screenFor(sq:Square):Pair<Int,Int> {
        val name=sq.name; val file=name[0]-'A'; val rank=name[1]-'1'; val whiteBottom=controller.userSide==Side.WHITE
        return if(whiteBottom) Pair(file,7-rank) else Pair(7-file,rank)
    }
    private fun symbol(p:Piece)=when(p){
        Piece.WHITE_KING->"♔"; Piece.WHITE_QUEEN->"♕"; Piece.WHITE_ROOK->"♖"; Piece.WHITE_BISHOP->"♗"; Piece.WHITE_KNIGHT->"♘"; Piece.WHITE_PAWN->"♙"
        Piece.BLACK_KING->"♚"; Piece.BLACK_QUEEN->"♛"; Piece.BLACK_ROOK->"♜"; Piece.BLACK_BISHOP->"♝"; Piece.BLACK_KNIGHT->"♞"; Piece.BLACK_PAWN->"♟"; else->""
    }
}
