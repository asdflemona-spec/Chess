plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "spec.asdflemona.pocketchess"
    compileSdk = 35
    defaultConfig { applicationId = "spec.asdflemona.pocketchess"; minSdk = 26; targetSdk = 35; versionCode = 201; versionName = "2.0.0-alpha2" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("com.github.bhlangonijr:chesslib:1.3.7") }
