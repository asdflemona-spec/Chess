# Pocket Chess Fresh 2.0.0-alpha1
Clean-room UI/controller rewrite. No v1.1.x game/turn/UI source is reused.

Architecture:
- chesslib 1.3.7 (Apache-2.0) is the proven rules/move-generation backend.
- ChessBoardView only collects explicit from→to user input.
- GameController is the only board mutator.
- RandomOpponent only receives a legal-move list and returns one random legal move.
- User moves are selected only from board.legalMoves(); opponent moves are selected only by RandomOpponent.

This alpha intentionally excludes archive/replay/gallery/PGN customization until the core turn/input behavior is device-verified.
