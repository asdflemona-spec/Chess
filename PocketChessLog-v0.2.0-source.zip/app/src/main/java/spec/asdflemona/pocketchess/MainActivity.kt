package spec.asdflemona.pocketchess

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity: Activity() {
    private lateinit var game: ChessGame
    private lateinit var board: ChessView
    private lateinit var log: TextView
    private lateinit var status: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); newGame() }
    private fun newGame() {
        game=ChessGame(); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(12,12,12,12); setBackgroundColor(Color.rgb(38,36,33))}
        val title=TextView(this).apply{text="Pocket Chess"; textSize=22f; setTextColor(Color.WHITE); gravity=17; setPadding(0,12,0,6)}
        status=TextView(this).apply{text="Your turn · White"; textSize=14f; setTextColor(Color.LTGRAY); gravity=17; setPadding(0,0,0,10)}
        board=ChessView(this,game){ afterHuman() }
        log=TextView(this).apply{textSize=15f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(49,47,43)); setPadding(16,14,16,14); setTextIsSelectable(true); minHeight=100}
        val bar=LinearLayout(this).apply{gravity=17}
        val reset=Button(this).apply{text="New game"; setOnClickListener{newGame()}}
        val copy=Button(this).apply{text="Copy moves"; setOnClickListener{(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("moves",game.record())); Toast.makeText(this@MainActivity,"Copied",Toast.LENGTH_SHORT).show()}}
        bar.addView(reset); bar.addView(copy); root.addView(title); root.addView(status); root.addView(board,LinearLayout.LayoutParams(-1,0,1f)); root.addView(log); root.addView(bar); setContentView(root); updateLog()
    }
    private fun updateLog(){ log.text=game.record().ifBlank{"Moves will appear here automatically."}; status.text=if(game.turn=='w') "Your turn · White" else "Computer thinking…" }
    private fun afterHuman(){ updateLog(); board.isEnabled=false; thread { val m=game.bestMove(900); runOnUiThread { if(m!=null) game.play(m); board.isEnabled=true; board.invalidate(); updateLog(); if(game.legal().isEmpty()) Toast.makeText(this, if(game.inCheck(game.turn)) "Checkmate" else "Draw", Toast.LENGTH_LONG).show() } } }
}

data class Move(val f:Int,val t:Int,val promo:Char='Q')
class ChessGame {
    val b=CharArray(64){'.'}; var turn='w'; private val hist=mutableListOf<String>(); private var ep=-1
    init { val back="RNBQKBNR"; for(i in 0..7){b[i]=back[i];b[8+i]='P';b[48+i]='p';b[56+i]=back[i].lowercaseChar()} }
    private fun white(p:Char)=p in "PNBRQK"; private fun mine(p:Char,s:Char)=if(s=='w')white(p) else p in "pnbrqk"
    var lastMove:Move?=null
    fun play(m:Move){ val p=b[m.f]; val capture=b[m.t]!='.'; if(p.lowercaseChar()=='p' && m.t==ep && b[m.t]=='.') b[m.t+(if(white(p)) -8 else 8)]='.'; b[m.t]=p; b[m.f]='.'; if(p.lowercaseChar()=='p' && (m.t/8==7||m.t/8==0)) b[m.t]=if(white(p))m.promo else m.promo.lowercaseChar(); ep=if(p.lowercaseChar()=='p'&&abs(m.t-m.f)==16)(m.t+m.f)/2 else -1; hist += notation(m,p,capture); lastMove=m; turn=if(turn=='w')'b' else 'w' }
    private fun notation(m:Move,p:Char,c:Boolean):String { val sq="${('a'.code+m.t%8).toChar()}${m.t/8+1}"; return (if(p.lowercaseChar()=='p') if(c) "${('a'.code+m.f%8).toChar()}x" else "" else p.uppercaseChar().toString()+(if(c)"x" else ""))+sq }
    fun record():String=hist.chunked(2).mapIndexed{i,x->"${i+1}. ${x.joinToString(" ")}"}.joinToString("   ")
    fun legal(s:Char=turn):List<Move>{ val out=ArrayList<Move>(); for(i in 0..63) if(mine(b[i],s)) for(m in pseudo(i)) { val old=b[m.t]; val pc=b[m.f]; b[m.t]=pc;b[m.f]='.'; val ok=!inCheck(s);b[m.f]=pc;b[m.t]=old;if(ok)out+=m }; return out }
    private fun pseudo(i:Int):List<Move>{ val p=b[i]; val s=if(white(p))'w' else 'b'; val r=i/8;val c=i%8;val o=ArrayList<Move>(); fun add(rr:Int,cc:Int){if(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(b[t]=='.'||!mine(b[t],s))o+=Move(i,t)}}; when(p.lowercaseChar()){
        'p'->{val d=if(s=='w')1 else -1; if(r+d in 0..7&&b[(r+d)*8+c]=='.'){o+=Move(i,(r+d)*8+c);val st=if(s=='w')1 else 6;if(r==st&&b[(r+2*d)*8+c]=='.')o+=Move(i,(r+2*d)*8+c)};for(dc in intArrayOf(-1,1))if(c+dc in 0..7&&r+d in 0..7){val t=(r+d)*8+c+dc;if((b[t]!='.'&&!mine(b[t],s))||t==ep)o+=Move(i,t)}}
        'n'->for((dr,dc) in arrayOf(2 to 1,2 to -1,-2 to 1,-2 to -1,1 to 2,1 to -2,-1 to 2,-1 to -2))add(r+dr,c+dc)
        'k'->for(dr in -1..1)for(dc in -1..1)if(dr!=0||dc!=0)add(r+dr,c+dc)
        'b','r','q'->{val ds=mutableListOf<Pair<Int,Int>>();if(p.lowercaseChar()!='r')ds+=listOf(1 to 1,1 to -1,-1 to 1,-1 to -1);if(p.lowercaseChar()!='b')ds+=listOf(1 to 0,-1 to 0,0 to 1,0 to -1);for((dr,dc)in ds){var rr=r+dr;var cc=c+dc;while(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(b[t]=='.')o+=Move(i,t) else {if(!mine(b[t],s))o+=Move(i,t);break};rr+=dr;cc+=dc}}}
    };return o}
    fun inCheck(s:Char):Boolean{val k=b.indexOf(if(s=='w')'K' else 'k');if(k<0)return true;val enemy=if(s=='w')'b' else 'w';for(i in 0..63)if(mine(b[i],enemy))if(pseudo(i).any{it.t==k})return true;return false}
    private fun eval():Int{var v=0;val valMap=mapOf('p' to 100,'n' to 320,'b' to 330,'r' to 500,'q' to 900,'k' to 20000);for(p in b)if(p!='.')v+=(valMap[p.lowercaseChar()]?:0)*(if(white(p))1 else -1);return v}
    fun bestMove(ms:Long):Move?{val deadline=System.currentTimeMillis()+ms;var best:Move?=null;var depth=1;while(System.currentTimeMillis()<deadline&&depth<=5){var bs=Int.MAX_VALUE;for(m in legal('b')){val snap=b.clone();val oldTurn=turn;playSilent(m);val sc=search(depth-1,-30000,30000,true,deadline);b.indices.forEach{b[it]=snap[it]};turn=oldTurn;if(System.currentTimeMillis()>=deadline)break;if(sc<bs){bs=sc;best=m}};depth++};return best?:legal('b').firstOrNull()}
    private fun playSilent(m:Move){b[m.t]=b[m.f];b[m.f]='.';turn=if(turn=='w')'b' else 'w'}
    private fun search(d:Int,a0:Int,beta0:Int,maxi:Boolean,dl:Long):Int{if(d==0||System.currentTimeMillis()>=dl)return eval();val ms=legal(if(maxi)'w' else 'b');if(ms.isEmpty())return eval();var a=a0;var be=beta0;if(maxi){var x=-30000;for(m in ms){val s=b.clone();playSilent(m);x=max(x,search(d-1,a,be,false,dl));b.indices.forEach{b[it]=s[it]};turn='w';a=max(a,x);if(be<=a)break};return x}else{var x=30000;for(m in ms){val s=b.clone();playSilent(m);x=min(x,search(d-1,a,be,true,dl));b.indices.forEach{b[it]=s[it]};turn='b';be=min(be,x);if(be<=a)break};return x}}
}

class ChessView(c:Context,val g:ChessGame,val moved:()->Unit):View(c){
    var sel=-1
    private val light=Paint().apply{color=Color.rgb(240,217,181)}
    private val dark=Paint().apply{color=Color.rgb(181,136,99)}
    private val selected=Paint().apply{color=Color.argb(175,246,246,105)}
    private val last=Paint().apply{color=Color.argb(120,205,210,70)}
    private val check=Paint().apply{color=Color.argb(180,220,55,55)}
    private val dot=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(125,40,40,40)}
    private val ring=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(120,40,40,40);style=Paint.Style.STROKE}
    private val txt=Paint(Paint.ANTI_ALIAS_FLAG).apply{textAlign=Paint.Align.CENTER;color=Color.BLACK}
    private val coord=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=18f;typeface=Typeface.DEFAULT_BOLD}

    override fun onDraw(c:Canvas){
        super.onDraw(c)
        val s=min(width,height)/8f
        for(r in 0..7) for(col in 0..7){
            val base=if((r+col)%2==0)dark else light
            c.drawRect(col*s,(7-r)*s,(col+1)*s,(8-r)*s,base)
        }
        fun square(i:Int,p:Paint){val r=i/8;val col=i%8;c.drawRect(col*s,(7-r)*s,(col+1)*s,(8-r)*s,p)}
        g.lastMove?.let{square(it.f,last);square(it.t,last)}
        if(sel>=0) square(sel,selected)
        val king=g.b.indexOf('K'); if(king>=0 && g.inCheck('w')) square(king,check)
        if(sel>=0){
            ring.strokeWidth=max(4f,s*.07f)
            for(m in g.legal().filter{it.f==sel}){
                val r=m.t/8;val col=m.t%8;val cx=(col+.5f)*s;val cy=(7-r+.5f)*s
                if(g.b[m.t]=='.') c.drawCircle(cx,cy,s*.13f,dot) else c.drawCircle(cx,cy,s*.40f,ring)
            }
        }
        txt.textSize=s*.68f
        val map=mapOf('K' to "♔",'Q' to "♕",'R' to "♖",'B' to "♗",'N' to "♘",'P' to "♙",'k' to "♚",'q' to "♛",'r' to "♜",'b' to "♝",'n' to "♞",'p' to "♟")
        for(i in 0..63) if(g.b[i]!='.') {val r=i/8;val col=i%8;c.drawText(map[g.b[i]]?:"",(col+.5f)*s,(7-r+.73f)*s,txt)}
        for(col in 0..7){coord.color=if(col%2==0)light.color else dark.color;c.drawText(('a'.code+col).toChar().toString(),(col+1)*s-18f,8*s-8f,coord)}
        for(r in 0..7){coord.color=if(r%2==0)dark.color else light.color;c.drawText((r+1).toString(),5f,(7-r)*s+20f,coord)}
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action!=MotionEvent.ACTION_UP||!isEnabled||g.turn!='w') return true
        val s=min(width,height)/8f; val col=(e.x/s).toInt(); val rr=7-(e.y/s).toInt()
        if(col !in 0..7||rr !in 0..7)return true
        val i=rr*8+col
        if(sel<0){if(g.b[i] in "PNBRQK")sel=i}
        else{
            val m=g.legal().firstOrNull{it.f==sel&&it.t==i}
            if(m!=null){g.play(m);sel=-1;invalidate();moved()}
            else sel=if(g.b[i] in "PNBRQK")i else -1
        }
        invalidate();return true
    }
}
