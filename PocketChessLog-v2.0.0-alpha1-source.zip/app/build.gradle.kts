plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "spec.asdflemona.pocketchess"
    compileSdk = 35
    defaultConfig { applicationId = "spec.asdflemona.pocketchess"; minSdk = 26; targetSdk = 35; versionCode = 200; versionName = "2.0.0-alpha1" }
}
dependencies { implementation("com.github.bhlangonijr:chesslib:1.3.7") }
