plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "spec.asdflemona.pocketchess"
    compileSdk = 35
    defaultConfig {
        applicationId = "spec.asdflemona.pocketchess"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
