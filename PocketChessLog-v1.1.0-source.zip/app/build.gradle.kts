plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "spec.asdflemona.pocketchess"
    compileSdk = 35
    defaultConfig {
        applicationId = "spec.asdflemona.pocketchess"
        minSdk = 23
        targetSdk = 35
        versionCode = 10
        versionName = "1.0.0"
    }
}

android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
