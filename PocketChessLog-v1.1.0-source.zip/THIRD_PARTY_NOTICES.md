# Third-party references / notices

Pocket Chess Log is an independent personal chess application.

The interaction and board design intentionally follow established open-source chess UI patterns, especially Lichess Mobile / Chessground: legal-move destinations, capture indicators, last-move/check highlights, coordinates, board orientation, move-list review and promotion selection.

Rule/state behavior follows established chess-library patterns, particularly chesslib's legal-move/state and draw-rule model (threefold repetition, fifty-move rule, insufficient material, stalemate).

The lightweight engine architecture follows common open-source chess-engine practice: iterative deepening, alpha-beta search, move ordering, a time budget, and background execution.

References:
- lichess-org/mobile — GPL-3.0: https://github.com/lichess-org/mobile
- lichess-org/chessground — GPL-3.0-or-later: https://github.com/lichess-org/chessground
- bhlangonijr/chesslib — Apache-2.0: https://github.com/bhlangonijr/chesslib

No Lichess trademarks or logos are included. The launcher icon is an original generated chess-knight image for Pocket Chess Log.
