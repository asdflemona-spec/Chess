# Pocket Chess Log v1.1.0

Offline personal chess app for Android.

## v1.1.0 integrated features
- Legal chess with castling, en passant and Q/R/B/N promotion picker
- Check, checkmate and stalemate
- Threefold repetition, fifty-move rule and insufficient-material draws
- SAN move record and PGN copy
- Automatic local archive of completed games
- Move-history review controls (start/back/forward/end)
- Board flip and play as White or Black
- Lichess/Chessground-inspired legal-move dots, capture rings, last-move and check highlights, coordinates
- Four lightweight AI levels with background iterative-deepening alpha-beta search
- Chess knight launcher icon
- Undo and new-game controls

See THIRD_PARTY_NOTICES.md for design/implementation references and licenses.
