# Pocket Chess Log v2.0.0-alpha3

Based directly on the verified v2.0.0-alpha2 architecture.

Changes:
- The app no longer ends games under the 50-move rule.
- Stalemate, threefold repetition, insufficient material and checkmate remain active.
- Piece appearance can be changed between Classic, Letters and Solid, and the choice persists.
- Human pawn promotion requires an explicit Queen/Rook/Bishop/Knight choice.
- RandomOpponent remains the only random-selection component; opponent promotions are simply part of its legal-move random choice.
