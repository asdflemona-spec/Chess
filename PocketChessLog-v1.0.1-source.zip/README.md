# Pocket Chess v0.1
Offline Android chess against a lightweight local alpha-beta engine. Every move is recorded and games can be copied as PGN-like coordinate notation.
