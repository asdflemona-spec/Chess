# Third-party design and implementation references

Pocket Chess is an independent personal chess application.

The interaction model and board presentation are intentionally modeled after Lichess Chessground (GPL-3.0-or-later): selection highlighting, legal-move dots/capture rings, last-move highlighting, check highlighting, and board-first layout.
https://github.com/lichess-org/chessground

Chess rules/state design was cross-checked against chesslib (Apache-2.0), particularly the separation of board state, legal move generation, undo/history, FEN/PGN concepts and perft-style validation.
https://github.com/bhlangonijr/chesslib

The lightweight computer-player architecture is modeled after MWM Chess (GPL-3.0-or-later): pure-Kotlin negamax/minimax family search, alpha-beta pruning, iterative deepening/time budget, move ordering and off-UI-thread calculation.
https://github.com/Matswm86/mwm-chess

No Lichess trademarks or logos are included. This project should be distributed under GPL-3.0-or-later when GPL-derived code is incorporated.
