package spec.asdflemona.pocketchess

import android.app.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.*
import android.graphics.*
import android.net.Uri
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: Activity() {
    private var game=ChessGame(); private lateinit var board:ChessView; private lateinit var moves:TextView; private lateinit var status:TextView
    private var human='w'; private var thinking=false; private var reviewPly:Int?=null; private var botPhase=0
    private val uiHandler=Handler(Looper.getMainLooper())
    private val boardImageRequest=4107
    override fun onCreate(b:Bundle?){super.onCreate(b);buildUi()}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==boardImageRequest && resultCode==RESULT_OK){
            val uri=data?.data?:return
            try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
            getSharedPreferences("board_style",0).edit().putString("image_uri",uri.toString()).apply()
            board.setBoardImage(uri);Toast.makeText(this,"Board photo applied",Toast.LENGTH_SHORT).show()
        }
    }
    private fun chooseBoardImage(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*";addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)}
        startActivityForResult(i,boardImageRequest)
    }
    private fun resetBoardImage(){getSharedPreferences("board_style",0).edit().remove("image_uri").apply();board.setBoardImage(null);Toast.makeText(this,"Default board restored",Toast.LENGTH_SHORT).show()}
    private fun buildUi(){
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(12,8,12,8)
            setBackgroundColor(Color.rgb(31,30,28))
        }
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(4,2,4,6)}
        val title=TextView(this).apply{text="Pocket Chess";textSize=19f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD}
        status=TextView(this).apply{textSize=13f;setTextColor(Color.rgb(220,220,215));gravity=Gravity.END;setPadding(12,6,12,6);setBackgroundColor(Color.rgb(60,58,54))}
        top.addView(title,LinearLayout.LayoutParams(0,-2,1f));top.addView(status);root.addView(top)

        board=ChessView(this,game,{ humanMoved() },{from,to,opts->choosePromotion(from,to,opts)},{ game.turn==human && !thinking && reviewPly==null })
        val boardLp=LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,4,0,8)}
        root.addView(board,boardLp)

        moves=TextView(this).apply{
            textSize=14f;setTextColor(Color.rgb(238,238,235));setBackgroundColor(Color.rgb(45,43,40));setPadding(14,10,14,10)
            minHeight=70;maxLines=3
        }
        root.addView(moves)

        fun btn(t:String,f:()->Unit)=Button(this).apply{
            text=t;textSize=12f;isAllCaps=false;minHeight=42;minimumHeight=0;minimumWidth=0
            setPadding(10,4,10,4);setOnClickListener{f()}
        }
        val nav=LinearLayout(this).apply{gravity=Gravity.CENTER;setPadding(0,5,0,2)}
        listOf(
            btn("|◀"){review(0)}, btn("◀"){review((reviewPly?:game.plyCount())-1)},
            btn("▶"){review((reviewPly?:game.plyCount())+1)}, btn("▶|"){review(game.plyCount())},
            btn("Flip"){board.flipped=!board.flipped;board.invalidate()}
        ).forEach{nav.addView(it,LinearLayout.LayoutParams(0,-2,1f))}
        root.addView(nav)
        val boardBar=LinearLayout(this).apply{gravity=Gravity.CENTER;setPadding(0,2,0,0)}
        listOf(btn("Board photo"){chooseBoardImage()},btn("Default board"){resetBoardImage()}).forEach{boardBar.addView(it,LinearLayout.LayoutParams(0,-2,1f))}
        root.addView(boardBar)

        val savedBoardUri=getSharedPreferences("board_style",0).getString("image_uri",null)?.let{runCatching{Uri.parse(it)}.getOrNull()}
        board.setBoardImage(savedBoardUri)

        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER;setPadding(0,2,0,0)}
        listOf(btn("Undo"){undoPair()},btn("New"){newGameDialog()},btn("Games"){showArchive()},btn("PGN"){copyPgn()}).forEach{
            bar.addView(it,LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(bar)
        setContentView(root);refresh()
    }
    private fun review(p:Int){if(thinking)return;val n=p.coerceIn(0,game.plyCount());reviewPly=if(n==game.plyCount())null else n;board.reviewBoard=reviewPly?.let{game.boardAt(it)};board.sel=-1;board.invalidate();refresh()}
    private fun newGameDialog(){if(thinking)return;AlertDialog.Builder(this).setTitle("Play as").setItems(arrayOf("White","Black")){_,i->human=if(i==0)'w' else 'b';startNew()}.show()}
    private fun startNew(){game=ChessGame();reviewPly=null;board.game=game;board.reviewBoard=null;board.flipped=human=='b';board.sel=-1;botPhase=0;refresh();board.invalidate();if(human=='b'){thinking=true;board.isEnabled=false;botPhase=1;refresh();uiHandler.postDelayed({computerMove()},420)}}
    private fun undoPair(){if(thinking)return;reviewPly=null;board.reviewBoard=null;if(game.undo())game.undo();board.sel=-1;botPhase=0;refresh();board.invalidate()}
    private fun copyPgn(){(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("PGN",game.pgn()));Toast.makeText(this,"PGN copied",Toast.LENGTH_SHORT).show()}
    private fun refresh(){moves.text=game.moveText().ifBlank{"Your game record appears here."};status.text=when{reviewPly!=null->"Review ${reviewPly}/${game.plyCount()}";game.result()!=null->game.resultText();thinking&&botPhase==1->"Bot is choosing a random legal move…";thinking->"Your move played";game.turn==human->"Your turn · choose a piece";else->"Bot turn"}}
    private fun humanMoved(){
        reviewPly=null;board.reviewBoard=null;board.sel=-1;botPhase=0;board.invalidate();refresh()
        if(game.result()!=null){finishGame();return}
        // Keep the player's move visible briefly so the random reply never feels like the app chose the player's move.
        thinking=true;board.isEnabled=false;refresh()
        uiHandler.postDelayed({ botPhase=1; refresh(); computerMove() },420)
    }
    private fun computerMove(){
        if(game.result()!=null){thinking=false;board.isEnabled=true;refresh();return}
        thinking=true;board.isEnabled=false;refresh()
        val snapshot=game.copyGame()
        thread{
            val m=snapshot.randomMove()
            runOnUiThread{
                if(m!=null && game.result()==null && game.turn!=human){game.play(m)}
                thinking=false;botPhase=0;board.isEnabled=true;board.sel=-1;board.invalidate();refresh()
                if(game.result()!=null)finishGame()
            }
        }
    }
    private fun finishGame(){GameArchive.save(this,game.pgn(),game.resultText(),human);AlertDialog.Builder(this).setTitle(game.result() ?: "Game over").setMessage(game.resultText()).setPositiveButton("New game"){_,_->newGameDialog()}.setNeutralButton("Copy PGN"){_,_->copyPgn()}.setNegativeButton("Close",null).show()}
    private fun choosePromotion(from:Int,to:Int,opts:List<Move>){val labels=arrayOf("♕ Queen","♖ Rook","♗ Bishop","♘ Knight");val chars=charArrayOf('Q','R','B','N');AlertDialog.Builder(this).setTitle("Promote pawn").setItems(labels){_,i->opts.firstOrNull{it.promotion==chars[i]}?.let{if(game.play(it)){board.sel=-1;board.invalidate();humanMoved()}}}.show()}
    private fun showArchive(){val games=GameArchive.load(this);if(games.isEmpty()){Toast.makeText(this,"No saved games yet",Toast.LENGTH_SHORT).show();return};val labels=games.map{it.optString("date")+"  ·  "+it.optString("result")}.toTypedArray();AlertDialog.Builder(this).setTitle("Saved games").setItems(labels){_,i->val p=games[i].optString("pgn");AlertDialog.Builder(this).setTitle(labels[i]).setMessage(p).setPositiveButton("Copy"){_,_->(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("PGN",p))}.setNegativeButton("Close",null).show()}.setNegativeButton("Close",null).show()}
}

object GameArchive{
    private const val PREF="game_archive";private const val KEY="games"
    fun load(c:Context):List<JSONObject>{return try{val a=JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]"));(0 until a.length()).map{a.getJSONObject(it)}}catch(e:Exception){emptyList()}}
    fun save(c:Context,pgn:String,result:String,human:Char){val a=JSONArray();val old=load(c);val o=JSONObject().put("date",SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date())).put("result",result).put("bot","Random Bot").put("side",human.toString()).put("pgn",pgn);a.put(o);old.take(99).forEach{a.put(it)};c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply()}
}

data class Move(val from:Int,val to:Int,val promotion:Char='Q',val castle:Boolean=false,val ep:Boolean=false)
data class State(val board:CharArray,val turn:Char,val castle:String,val ep:Int,val half:Int,val full:Int,val move:Move?,val san:String)

class ChessGame {
    var board=CharArray(64){'.'};var turn='w';private var castle="KQkq";private var ep=-1;private var half=0;private var full=1
    private val history=mutableListOf<State>();private val sans=mutableListOf<String>();private val positions=mutableListOf<String>();var lastMove:Move?=null
    init{reset();positions+=positionKey()}
    private fun reset(){val back="RNBQKBNR";for(i in 0..7){board[i]=back[i];board[8+i]='P';board[48+i]='p';board[56+i]=back[i].lowercaseChar()}}
    fun copyGame():ChessGame{val g=ChessGame();g.board=board.clone();g.turn=turn;g.castle=castle;g.ep=ep;g.half=half;g.full=full;g.history.clear();g.history.addAll(history.map{it.copy(board=it.board.clone())});g.sans.clear();g.sans.addAll(sans);g.positions.clear();g.positions.addAll(positions);g.lastMove=lastMove;return g}
    fun plyCount()=sans.size
    fun boardAt(ply:Int):CharArray=if(ply>=history.size)board.clone() else history[ply].board.clone()
    private fun white(p:Char)=p in "PNBRQK";private fun mine(p:Char,s:Char)=if(s=='w')white(p) else p in "pnbrqk";private fun enemy(s:Char)=if(s=='w')'b' else 'w'
    private fun sq(i:Int)="${('a'.code+i%8).toChar()}${i/8+1}"
    private fun positionKey()=String(board)+"|$turn|$castle|$ep"
    fun legal(s:Char=turn):List<Move>{val out=ArrayList<Move>();for(i in 0..63)if(mine(board[i],s))for(m in pseudo(i,s)){val snap=snapshot(m,"");applyRaw(m);val ok=!inCheck(s);restore(snap);if(ok)out+=m};return out}
    private fun pseudo(i:Int,s:Char):List<Move>{val p=board[i];val r=i/8;val c=i%8;val out=ArrayList<Move>();fun add(rr:Int,cc:Int){if(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(board[t]=='.'||!mine(board[t],s))out+=Move(i,t)}}
        when(p.lowercaseChar()){'p'->{val d=if(s=='w')1 else -1;val pr=if(s=='w')7 else 0;fun pm(t:Int,epc:Boolean=false){if(t/8==pr)for(q in "QRBN")out+=Move(i,t,q,false,epc) else out+=Move(i,t,'Q',false,epc)};val one=r+d;if(one in 0..7&&board[one*8+c]=='.'){pm(one*8+c);val st=if(s=='w')1 else 6;val two=r+2*d;if(r==st&&board[two*8+c]=='.')out+=Move(i,two*8+c)};for(dc in intArrayOf(-1,1)){val cc=c+dc;if(one in 0..7&&cc in 0..7){val t=one*8+cc;if(board[t]!='.'&&!mine(board[t],s))pm(t) else if(t==ep)pm(t,true)}}};'n'->for((dr,dc) in arrayOf(2 to 1,2 to -1,-2 to 1,-2 to -1,1 to 2,1 to -2,-1 to 2,-1 to -2))add(r+dr,c+dc);'b','r','q'->{val ds=ArrayList<Pair<Int,Int>>();if(p.lowercaseChar()!='r')ds+=listOf(1 to 1,1 to -1,-1 to 1,-1 to -1);if(p.lowercaseChar()!='b')ds+=listOf(1 to 0,-1 to 0,0 to 1,0 to -1);for((dr,dc)in ds){var rr=r+dr;var cc=c+dc;while(rr in 0..7&&cc in 0..7){val t=rr*8+cc;if(board[t]=='.')out+=Move(i,t)else{if(!mine(board[t],s))out+=Move(i,t);break};rr+=dr;cc+=dc}}};'k'->{for(dr in -1..1)for(dc in -1..1)if(dr!=0||dc!=0)add(r+dr,c+dc);if(!inCheck(s)){if(s=='w'&&i==4){if('K' in castle&&board[7]=='R'&&board[5]=='.'&&board[6]=='.'&&!attacked(5,'b')&&!attacked(6,'b'))out+=Move(4,6,castle=true);if('Q' in castle&&board[0]=='R'&&board[3]=='.'&&board[2]=='.'&&board[1]=='.'&&!attacked(3,'b')&&!attacked(2,'b'))out+=Move(4,2,castle=true)};if(s=='b'&&i==60){if('k' in castle&&board[63]=='r'&&board[61]=='.'&&board[62]=='.'&&!attacked(61,'w')&&!attacked(62,'w'))out+=Move(60,62,castle=true);if('q' in castle&&board[56]=='r'&&board[59]=='.'&&board[58]=='.'&&board[57]=='.'&&!attacked(59,'w')&&!attacked(58,'w'))out+=Move(60,58,castle=true)}}}};return out}
    private fun attacked(t:Int,by:Char):Boolean{for(i in 0..63)if(mine(board[i],by)){val p=board[i].lowercaseChar();val r=i/8;val c=i%8;val tr=t/8;val tc=t%8;when(p){'p'->if(tr-r==(if(by=='w')1 else -1)&&abs(tc-c)==1)return true;'n'->if((abs(tr-r)==2&&abs(tc-c)==1)||(abs(tr-r)==1&&abs(tc-c)==2))return true;'k'->if(max(abs(tr-r),abs(tc-c))==1)return true;'b','r','q'->{val dr=tr-r;val dc=tc-c;val diag=abs(dr)==abs(dc);val straight=dr==0||dc==0;if((p=='b'&&diag)||(p=='r'&&straight)||(p=='q'&&(diag||straight))){val sr=dr.sign;val sc=dc.sign;var rr=r+sr;var cc=c+sc;var clear=true;while(rr!=tr||cc!=tc){if(board[rr*8+cc]!='.'){clear=false;break};rr+=sr;cc+=sc};if(clear)return true}}}};return false}
    fun inCheck(s:Char):Boolean{val k=board.indexOf(if(s=='w')'K' else 'k');return k<0||attacked(k,enemy(s))}
    private fun snapshot(m:Move?,san:String)=State(board.clone(),turn,castle,ep,half,full,m,san)
    private fun restore(s:State){board=s.board.clone();turn=s.turn;castle=s.castle;ep=s.ep;half=s.half;full=s.full}
    private fun applyRaw(m:Move){val p=board[m.from];if(m.ep){val cap=m.to+(if(white(p))-8 else 8);board[cap]='.'};board[m.to]=p;board[m.from]='.';if(m.castle){if(m.to==6){board[5]=board[7];board[7]='.'};if(m.to==2){board[3]=board[0];board[0]='.'};if(m.to==62){board[61]=board[63];board[63]='.'};if(m.to==58){board[59]=board[56];board[56]='.'}};if(p.lowercaseChar()=='p'&&(m.to/8==0||m.to/8==7))board[m.to]=if(white(p))m.promotion else m.promotion.lowercaseChar()}
    private fun makeRawState(m:Move){val p=board[m.from];val captured=if(m.ep)true else board[m.to]!='.';applyRaw(m);updateRights(m,p);ep=if(p.lowercaseChar()=='p'&&abs(m.to-m.from)==16)(m.to+m.from)/2 else -1;half=if(p.lowercaseChar()=='p'||captured)0 else half+1;if(turn=='b')full++;turn=enemy(turn)}
    fun play(m:Move):Boolean{val lm=legal().firstOrNull{it.from==m.from&&it.to==m.to&&it.promotion==m.promotion}?:return false;val p=board[lm.from];val captured=lm.ep||board[lm.to]!='.';history+=snapshot(lm,"");val sanBase=sanBase(lm,p,captured);makeRawState(lm);lastMove=lm;val suffix=if(inCheck(turn))if(legal().isEmpty())"#" else "+" else "";sans+=sanBase+suffix;positions+=positionKey();return true}
    private fun updateRights(m:Move,p:Char){if(p=='K')castle=castle.replace("K","").replace("Q","");if(p=='k')castle=castle.replace("k","").replace("q","");if(m.from==0||m.to==0)castle=castle.replace("Q","");if(m.from==7||m.to==7)castle=castle.replace("K","");if(m.from==56||m.to==56)castle=castle.replace("q","");if(m.from==63||m.to==63)castle=castle.replace("k","")}
    private fun sanBase(m:Move,p:Char,cap:Boolean):String{if(m.castle)return if(m.to%8==6)"O-O" else "O-O-O";val pc=p.uppercaseChar();val piece=if(pc=='P')"" else pc.toString();var dis="";if(pc!='P'){val peers=legal().filter{it.to==m.to&&it.from!=m.from&&board[it.from].uppercaseChar()==pc};if(peers.isNotEmpty()){val sameFile=peers.any{it.from%8==m.from%8};val sameRank=peers.any{it.from/8==m.from/8};dis=when{!sameFile->('a'.code+m.from%8).toChar().toString();!sameRank->(m.from/8+1).toString();else->sq(m.from)}}}else if(cap)dis=('a'.code+m.from%8).toChar().toString();val promo=if(pc=='P'&&(m.to/8==0||m.to/8==7))"=${m.promotion}" else "";return piece+dis+(if(cap)"x" else "")+sq(m.to)+promo}
    fun undo():Boolean{if(history.isEmpty())return false;val s=history.removeAt(history.lastIndex);if(sans.isNotEmpty())sans.removeAt(sans.lastIndex);if(positions.size>1)positions.removeAt(positions.lastIndex);restore(s);lastMove=history.lastOrNull()?.move;return true}
    private fun repetition()=positions.count{it==positionKey()}>=3
    private fun insufficient():Boolean{val pieces=board.filter{it!='.'&&it.lowercaseChar()!='k'};if(pieces.isEmpty())return true;if(pieces.any{it.lowercaseChar() in "pqr"})return false;if(pieces.size==1)return pieces[0].lowercaseChar() in "bn";if(pieces.all{it.lowercaseChar()=='b'}){val colors=board.indices.filter{board[it].lowercaseChar()=='b'}.map{(it/8+it%8)%2}.distinct();return colors.size==1};return false}
    fun result():String?{val l=legal();if(l.isEmpty())return if(inCheck(turn))if(turn=='w')"0-1" else "1-0" else "1/2-1/2";if(half>=100||repetition()||insufficient())return "1/2-1/2";return null}
    fun resultText():String{val l=legal();if(l.isEmpty())return if(inCheck(turn))if(turn=='w')"Black wins by checkmate" else "White wins by checkmate" else "Draw by stalemate";if(half>=100)return "Draw by fifty-move rule";if(repetition())return "Draw by threefold repetition";if(insufficient())return "Draw by insufficient material";return "Game in progress"}
    fun moveText()=sans.chunked(2).mapIndexed{i,x->"${i+1}. ${x.joinToString("  ")}"}.joinToString("    ")
    fun pgn():String="[Event \"Pocket Chess\"]\n[Site \"Android\"]\n[Date \"${SimpleDateFormat("yyyy.MM.dd",Locale.US).format(Date())}\"]\n[Result \"${result()?:"*"}\"]\n\n${moveText()} ${result()?:"*"}"
    fun randomMove():Move? = legal().randomOrNull()
}
class ChessView(c:Context,var game:ChessGame,val moved:()->Unit,val promote:(Int,Int,List<Move>)->Unit,val canHumanMove:()->Boolean):View(c){var sel=-1;var flipped=false;var reviewBoard:CharArray?=null;private var boardBitmap:Bitmap?=null;private val light=Paint().apply{color=Color.argb(150,240,217,181)};private val dark=Paint().apply{color=Color.argb(150,181,136,99)};private val selected=Paint().apply{color=Color.argb(190,246,246,105)};private val check=Paint().apply{color=Color.argb(185,220,55,55)};private val dot=Paint(1).apply{color=Color.argb(130,30,30,30)};private val ring=Paint(1).apply{color=Color.argb(130,30,30,30);style=Paint.Style.STROKE};private val txt=Paint(1).apply{textAlign=Paint.Align.CENTER;color=Color.BLACK};private val coord=Paint(1).apply{textSize=18f;typeface=Typeface.DEFAULT_BOLD}
    override fun onMeasure(w:Int,h:Int){val ww=MeasureSpec.getSize(w);setMeasuredDimension(ww,ww)}
    private fun screen(i:Int):Pair<Int,Int>{val f=i%8;val r=i/8;return if(!flipped)f to (7-r) else (7-f) to r}
    private fun index(col:Int,row:Int):Int=if(!flipped)(7-row)*8+col else row*8+(7-col)
    fun setBoardImage(uri:Uri?){boardBitmap=null;if(uri!=null){try{context.contentResolver.openInputStream(uri)?.use{boardBitmap=BitmapFactory.decodeStream(it)}}catch(_:Exception){boardBitmap=null}};invalidate()}
    override fun onDraw(c:Canvas){val s=width/8f;val b=reviewBoard?:game.board;boardBitmap?.let{c.drawBitmap(it,null,RectF(0f,0f,width.toFloat(),height.toFloat()),Paint(Paint.ANTI_ALIAS_FLAG))};for(row in 0..7)for(col in 0..7){val i=index(col,row);val r=i/8;val f=i%8;c.drawRect(col*s,row*s,(col+1)*s,(row+1)*s,if((r+f)%2==0)light else dark)};fun hi(i:Int,p:Paint){val(qx,qy)=screen(i);c.drawRect(qx*s,qy*s,(qx+1)*s,(qy+1)*s,p)};if(reviewBoard==null){if(sel>=0)hi(sel,selected);val k=game.board.indexOf(if(game.turn=='w')'K' else 'k');if(k>=0&&game.inCheck(game.turn))hi(k,check);if(sel>=0){ring.strokeWidth=s*.07f;for(m in game.legal().filter{it.from==sel}){val(sc,sr)=screen(m.to);val cx=(sc+.5f)*s;val cy=(sr+.5f)*s;if(game.board[m.to]=='.')c.drawCircle(cx,cy,s*.13f,dot)else c.drawCircle(cx,cy,s*.40f,ring)}}};for(i in 0..63)if(b[i]!='.'){val(sc,sr)=screen(i);drawClassicPiece(c,b[i],(sc+.5f)*s,(sr+.5f)*s,s)};for(col in 0..7){val file=if(!flipped)col else 7-col;coord.color=Color.argb(190,30,30,30);c.drawText(('a'.code+file).toChar().toString(),(col+1)*s-18,8*s-8,coord)};for(row in 0..7){val rank=if(!flipped)8-row else row+1;coord.color=Color.argb(190,30,30,30);c.drawText(rank.toString(),5f,row*s+20,coord)}}
    private fun drawClassicPiece(c:Canvas,p:Char,cx:Float,cy:Float,s:Float){
        val glyph=when(p){'K'->"♔";'Q'->"♕";'R'->"♖";'B'->"♗";'N'->"♘";'P'->"♙";'k'->"♚";'q'->"♛";'r'->"♜";'b'->"♝";'n'->"♞";'p'->"♟";else->""}
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{textAlign=Paint.Align.CENTER;textSize=s*.78f;typeface=Typeface.create(Typeface.SERIF,Typeface.NORMAL);color=if(p.isUpperCase())Color.WHITE else Color.rgb(25,25,25);style=Paint.Style.FILL;setShadowLayer(s*.035f,0f,s*.02f,if(p.isUpperCase())Color.BLACK else Color.WHITE)}
        setLayerType(LAYER_TYPE_SOFTWARE,null)
        val fm=paint.fontMetrics;c.drawText(glyph,cx,cy-(fm.ascent+fm.descent)/2f,paint)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP||!isEnabled||reviewBoard!=null)return true;if(!canHumanMove())return true;val s=width/8f;val col=(e.x/s).toInt();val row=(e.y/s).toInt();if(col !in 0..7||row !in 0..7)return true;val i=index(col,row);val mine=if(game.turn=='w')"PNBRQK" else "pnbrqk";if(sel<0){if(game.board[i] in mine){sel=i;invalidate()}}else{val opts=game.legal().filter{it.from==sel&&it.to==i};if(opts.isNotEmpty()){if(opts.size>1){promote(sel,i,opts);return true};game.play(opts.first());sel=-1;invalidate();moved()}else sel=if(game.board[i] in mine)i else -1};invalidate();return true}
}
