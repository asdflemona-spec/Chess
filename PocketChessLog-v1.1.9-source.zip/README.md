# Pocket Chess Log v1.1.2

Offline personal chess app for Android.

## v1.1.2 integrated features
- Legal chess with castling, en passant and Q/R/B/N promotion picker
- Check, checkmate and stalemate
- Threefold repetition, fifty-move rule and insufficient-material draws
- SAN move record and PGN copy
- Automatic local archive of completed games
- Move-history review controls (start/back/forward/end)
- Board flip and play as White or Black
- Lichess/Chessground-inspired legal-move dots, capture rings, last-move and check highlights, coordinates
- Four lightweight AI levels with background iterative-deepening alpha-beta search
- Chess knight launcher icon
- Undo and new-game controls

See THIRD_PARTY_NOTICES.md for design/implementation references and licenses.


## v1.1.2
- Computer player now chooses uniformly from the current legal move list (Random Bot).
- Search/evaluation/alpha-beta engine code removed.
- Cute cat-chess launcher icon; CC0 source details in ICON_LICENSE.md.
- Includes the v1.1.1 finishGame Kotlin syntax fix.


## v1.1.9 turn model
Turn ownership is derived only from move-history ply parity. White user: even ply=user, odd ply=random. Black user: even ply=random, odd ply=user. No bot/human turn flags are used.
