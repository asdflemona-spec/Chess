# App icon source / license

The cat-chess character concept is adapted from **Cat chess set** by OgreofWart / DarkEvil ink on OpenGameArt.
The source asset is published under **CC0** (public-domain dedication).
Source page: https://opengameart.org/content/cat-chess-set

The launcher icon in this package is a simplified app-icon adaptation made from that CC0 cat-chess concept.
