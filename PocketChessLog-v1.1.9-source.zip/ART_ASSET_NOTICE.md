# Art asset notice

Visual direction for the cat-themed chess pieces is based on the CC0 "Cat chess set" by OgreofWart @ DarkEvil ink, published on OpenGameArt.
Source: https://opengameart.org/content/cat-chess-set
License: CC0 / public domain dedication.

Because the original ZIP could not be fetched in the build-preparation environment, the app uses an original lightweight vector renderer following that CC0 set's feline visual language rather than redistributing the original PNG files. The standard king/queen/rook/bishop/knight/pawn silhouettes remain distinct for playability.
